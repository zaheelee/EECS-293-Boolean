package jsa70.lexer.src;

public interface Factor
{
}
